#!/bin/bash

docker build -t unimore-prediction-api .