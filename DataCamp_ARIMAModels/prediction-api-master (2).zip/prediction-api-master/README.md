# Prediction API Container

- Reference Link for API Documentation: http://127.0.0.1:3050/apidocs/