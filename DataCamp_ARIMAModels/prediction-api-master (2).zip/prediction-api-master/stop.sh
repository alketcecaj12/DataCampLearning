#!/bin/bash

docker stop unimore-prediction-api
docker rm unimore-prediction-api
